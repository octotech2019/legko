<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Laravel</title>

    <!-- Fonts -->
    <link href='https://fonts.googleapis.com/css?family=Montserrat:400,700' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Playfair+Display:400,700,900' rel='stylesheet' type='text/css'>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

    <!-- Styles -->
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/responsive.css')); ?>">

    <!--  Bootstrap CDN-->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
</head>
<body>
    <header>
        <div class="top-nav container">
            <div class="logo">LEGKO.KG</div>
            <ul>
                <li><a href="#">LINK1</a></li>
                <li><a href="#">LINK2</a></li>
                <li><a href="#">LINK3</a></li>
                <li><a href="#">LINK4</a></li>
                <li><a href="#">LINK5</a></li>
            </ul>
        </div> <!-- end-of-top-nav-->
        <div class="hero container">
            <div class="hero-copy">
                <h1 class="text-center"> LEGKO </h1>
                <p class="text-center">Делай покупки</p>
                <div class="hero-buttons">
                    <a href="#" class="button button-white"> Button 1</a>
                    <a href="#" class="button button-white"> Button 2</a>
                </div>
            </div> <!-- end hero-copy -->

            <div class="hero-image">
                <img src="img/macbook-pro.png" alt="carousel image">
            </div>
        </div>  <!-- end carousel -->
    </header>

    <div class="featured-section">
        <div class="container">
            <h1 class="text-center"> Какой-то заголовок </h1>
            <p class="section-description"> Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aspernatur, at commodi deleniti dicta doloribus dolorum et exercitationem facilis impedit labore libero molestiae officiis, quas quod unde voluptates voluptatum! Dolores, id.</p>
            <div class="text-center button-container">
                <a href="#" class="button"> Button 1</a>
                <a href="#" class="button"> Button 2</a>
            </div>
        <div class="products text-center">
            <div class="product">
                <a href="#"><img src="img/product1.jpg" alt="product"></a>
                <a href="#"><div class="product-name">MacBook Pro</div></a>
                <div class="product-price">$2499.99</div>
            </div>
            <div class="product">
                <a href="#"><img src="img/product1.jpg" alt="product"></a>
                <a href="#"><div class="product-name">MacBook Pro</div></a>
                <div class="product-price">$2499.99</div>
            </div>
            <div class="product">
                <a href="#"><img src="img/product1.jpg" alt="product"></a>
                <a href="#"><div class="product-name">MacBook Pro</div></a>
                <div class="product-price">$2499.99</div>
            </div>
            <div class="product">
                <a href="#"><img src="img/product1.jpg" alt="product"></a>
                <a href="#"><div class="product-name">MacBook Pro</div></a>
                <div class="product-price">$2499.99</div>
            </div>
            <div class="product">
                <a href="#"><img src="img/product1.jpg" alt="product"></a>
                <a href="#"><div class="product-name">MacBook Pro</div></a>
                <div class="product-price">$2499.99</div>
            </div>
            <div class="product">
                <a href="#"><img src="img/product1.jpg" alt="product"></a>
                <a href="#"><div class="product-name">MacBook Pro</div></a>
                <div class="product-price">$2499.99</div>
            </div>
            <div class="product">
                <a href="#"><img src="img/product1.jpg" alt="product"></a>
                <a href="#"><div class="product-name">MacBook Pro</div></a>
                <div class="product-price">$2499.99</div>
            </div>
            <div class="product">
                <a href="#"><img src="img/product1.jpg" alt="product"></a>
                <a href="#"><div class="product-name">MacBook Pro</div></a>
                <div class="product-price">$2499.99</div>
            </div>
        </div> <!-- end products -->

        <div class="text-center button-container">
            <a href="#" class="button"> View more products</a>
        </div>

        </div> <!-- end container-->
    </div> <!-- end featured section-->

    <div class="popular-section">
        <div class="container">
            <h1 class="text-center"> Какой-то заголовок </h1>
            <p class="section-description"> Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aspernatur, at commodi deleniti dicta doloribus dolorum et exercitationem facilis impedit labore libero molestiae officiis, quas quod unde voluptates voluptatum! Dolores, id.</p>
            <div class="products text-center">
                <div class="product">
                    <a href="#"><img src="img/product1.jpg" alt="product"></a>
                    <a href="#"><div class="product-name">MacBook Pro</div></a>
                    <div class="product-price">$2499.99</div>
                </div>
                <div class="product">
                    <a href="#"><img src="img/product1.jpg" alt="product"></a>
                    <a href="#"><div class="product-name">MacBook Pro</div></a>
                    <div class="product-price">$2499.99</div>
                </div>
                <div class="product">
                    <a href="#"><img src="img/product1.jpg" alt="product"></a>
                    <a href="#"><div class="product-name">MacBook Pro</div></a>
                    <div class="product-price">$2499.99</div>
                </div>
                <div class="product">
                    <a href="#"><img src="img/product1.jpg" alt="product"></a>
                    <a href="#"><div class="product-name">MacBook Pro</div></a>
                    <div class="product-price">$2499.99</div>
                </div>
                <div class="product">
                    <a href="#"><img src="img/product1.jpg" alt="product"></a>
                    <a href="#"><div class="product-name">MacBook Pro</div></a>
                    <div class="product-price">$2499.99</div>
                </div>
                <div class="product">
                    <a href="#"><img src="img/product1.jpg" alt="product"></a>
                    <a href="#"><div class="product-name">MacBook Pro</div></a>
                    <div class="product-price">$2499.99</div>
                </div>
                <div class="product">
                    <a href="#"><img src="img/product1.jpg" alt="product"></a>
                    <a href="#"><div class="product-name">MacBook Pro</div></a>
                    <div class="product-price">$2499.99</div>
                </div>
                <div class="product">
                    <a href="#"><img src="img/product1.jpg" alt="product"></a>
                    <a href="#"><div class="product-name">MacBook Pro</div></a>
                    <div class="product-price">$2499.99</div>
                </div>
            </div> <!-- end products -->

            <div class="text-center button-container">
                <a href="#" class="button"> View more products</a>
            </div>

        </div> <!-- end container-->
    </div> <!-- end popular section-->
    <footer>
        <div class="footer-content container">
            <div class="made-with">Made with <i class="fa fa-heart"></i> by OCTOTECH</div>
            <ul>
                <li>Follow Me:</li>
                <li><a href="#"><i class="fa fa-globe"></i></a></li>
                <li><a href="#"><i class="fa fa-youtube"></i></a></li>
                <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                <li><a href="#"><i class="fa fa-twitter"></i></a></li>
            </ul>
        </div> <!-- end footer -->
    </footer>
</body>
</html>
<?php /**PATH G:\openserver\OSPanel\domains\legko.kg\resources\views/landingpage.blade.php ENDPATH**/ ?>